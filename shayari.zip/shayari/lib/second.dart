import 'package:flutter/material.dart';
import 'package:shayari_app/model.dart';
import 'package:shayari_app/third.dart';

class second extends StatefulWidget {
 int index;

  second(this.index);

  @override
  State<second> createState() => _secondState();
}

class _secondState extends State<second> {
  List<String> l=[];
  @override
  void initState() {
  super.initState();
  switch(widget.index)
  {
    case 0:
      l=model.wish;
      break;
    case 1:
      l=model.friend;
      break;
    case 2:
      l=model.funny;
      break;
    case 3:
      l=model.god;
      break;
    case 4:
      l=model.life;
      break;
  }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Love Shayari"),
      ),
        backgroundColor: Colors.lightGreen,
        body: ListView.builder(itemCount: model.poems.length,itemBuilder: (context, index) {
          return Card(
            elevation: 10,
            color: Colors.black54,
            margin: EdgeInsets.all(10),
            child:  ListTile(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return third(index,l);
                },));
              },
              title: Text(l[index],overflow: TextOverflow.ellipsis,maxLines: 1,),
              leading: Container(
                padding: EdgeInsets.all(5),
                child: Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                    image: DecorationImage(image: AssetImage("img/${model.profile[widget.index]}"),fit: BoxFit.cover),
                  ),
                ),
              ),
            ),
          );
        },)
    );
  }
}
