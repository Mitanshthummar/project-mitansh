import 'package:flutter/material.dart';

import 'first.dart';

void main()
{
  runApp(MaterialApp(
    home:first(),
  ));
}