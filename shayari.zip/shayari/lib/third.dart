import 'package:flutter/material.dart';
class third extends StatefulWidget {
  int index;
  List<String> list;
  third(this.index,this.list);

  @override
  State<third> createState() => _thirdState();
}

class _thirdState extends State<third> {

  @override
  Widget build(BuildContext context) {
    
    return Scaffold(
      appBar: AppBar(
        title: Text("Love Shayari"),
      ),
      body:Column(
       children: [
         // Container(
         //   height: 50,
         //   width: 1000,
         //   color: Colors.green,
         //   margin: EdgeInsets.all(50),
         // ),
         Expanded(
           child: Center(
             child: Container(
               decoration: BoxDecoration(
                 gradient: LinearGradient(colors: [Colors.orange,Colors.white,Colors.green])
               ),
               alignment:Alignment.center,
               height: 500,
               width: 500,
               child:Text(widget.list[widget.index]),
             ),
           ),
         ),
         Container(
           height: 50,
           width: 1000,
           color: Colors.green,
           margin: EdgeInsets.all(20),
           child: Row(
             children: [
               Expanded(
                 child: IconButton(onPressed: () {

                 }, icon: Icon(Icons.copy),color: Colors.white),
               ),
               Expanded(
                 child: IconButton(onPressed: () {
                   Text(widget.list[widget.index--]);
                   setState(() {

                   });
                 }, icon: Icon(Icons.navigate_before),color: Colors.white),
               ),
               Expanded(
                 child: IconButton(onPressed: () {
                   Text(widget.list[widget.index++]);

                   setState(() {
                     if(widget.index>=5)
                     {
                       Text(widget.list[widget.index++]);
                     }
                   });
                 }, icon: Icon(Icons.navigate_next),color: Colors.white),
               ),
               Expanded(
                 child: IconButton(onPressed: () {

                 }, icon: Icon(Icons.share),color: Colors.white),
               ),
             ],
           ),
         ),
       ],
      ),
    );
  }
}
