import 'package:flutter/material.dart';
import 'package:shayari_app/model.dart';
import 'package:shayari_app/second.dart';

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Love Shayari"),
      ),
      backgroundColor: Colors.pink,
      body: ListView.builder(itemCount: model.poems.length,itemBuilder: (context, index) {
        return Card(
          elevation: 10,
          color: Colors.black,
          margin: EdgeInsets.all(10),
          child: ListTile(
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return second(index);
              },));
            },
            title: Text(model.poems[index],style: TextStyle(color: Colors.green),),
            leading: Container(
              padding: EdgeInsets.all(5),
              child: Container(
                height: 60,
                width: 60,
                decoration: BoxDecoration(
                    image: DecorationImage(image: AssetImage("img/${model.profile[index]}"),fit: BoxFit.cover)
                ),
              ),
            ),
          ),
        );
      },),
    );
  }


}
