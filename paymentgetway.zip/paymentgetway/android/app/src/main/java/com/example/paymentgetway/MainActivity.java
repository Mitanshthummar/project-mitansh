package com.example.paymentgetway;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
