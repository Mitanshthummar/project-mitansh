package com.example.get_api2;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
