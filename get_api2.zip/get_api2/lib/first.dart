import 'dart:convert';
import 'package:http/http.dart' as http;

import 'package:flutter/material.dart';
import 'package:get_api2/student.dart';


class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {

  user? s;

  @override
  void initState() {
    get();
  }

  get() async {
    var url = Uri.https('reqres.in', 'api/users?page=2');
    var response = await http.get(url);
    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');

    Map<String, dynamic> m = jsonDecode(response.body);

    s = user.fromJson(m);
    setState(() {

    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("api2"),
      ),
      body: ListView.builder(itemCount: s!.data!.length,itemBuilder: (context, index) {
        return ListTile(
            title:
            Text("${s!.data![index].name}"),
            subtitle: Text("${s!.data![index].year}"),
          leading: Text("${s!.data![index].id}"),
        )
        ;
      },),
    );
  }


}
