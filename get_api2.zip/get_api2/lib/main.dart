import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get_api2/first.dart';

void main() {
  runApp(MaterialApp(
    home: first(),
  ));
}
